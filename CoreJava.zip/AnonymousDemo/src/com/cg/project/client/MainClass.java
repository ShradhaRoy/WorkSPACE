package com.cg.project.client;

public class MainClass {
	public static void main(String arga[]) {
		ProjectServices services=new ProjectServices() {

			@Override
			public void developProject() {
					System.out.println("IT Project has been developed");
			
			
			}
	};

}
}
