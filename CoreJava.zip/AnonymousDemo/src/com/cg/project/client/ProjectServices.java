package com.cg.project.client;

public interface ProjectServices {
	public void developProject() ;
		

}
