package com.cg.Arithmeticoperations.client;

public class Arithmetic implements Runnable {
	@Override
	public void run() {
		
		Thread t=Thread.currentThread();
		
		if(t.getName().equals("evenThread"))
				for(int i=1;i<=100;i++) 
					if(i%2==0)
					System.out.println("Even numbers  "+i);
					else
						System.out.println("odd numbers"+i);
					
		if(t.getName().equals("primeThread"))
				
				for(int i=1;i<=100;i++) {
					int count=1;
					for(int j=1;i<=i/2;i++) {
						if(i%j==0)
							count=0;
					}
					if(count==1)
					
					System.out.println(i+"is prime");
				}
			
			
			System.out.println("End of THread Task");

}
}