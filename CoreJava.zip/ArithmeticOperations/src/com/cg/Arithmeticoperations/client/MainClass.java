package com.cg.Arithmeticoperations.client;

public class MainClass {
	public static void main(String[] args) {
		Arithmetic resource=new Arithmetic ();
		
		Thread th1=new Thread(resource,"evenThread");
		
		Thread th3=new Thread(resource,"primeThread");
		th1.start();
		th3.start();

	}


}
