package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.List;
import com.cg.bankig.beans.Account;
import com.cg.banking.util.AccountDBUtil;
public class AccountDAOImpl implements AccountDAO {

	@Override
	public Account save(Account account) {
		account.setAccountNo(AccountDBUtil.getACCOUNT_NUMBER());
		account.setPinNumber((int) (Math.random()*1000));
		AccountDBUtil.customerAccountDetails.put((long) account.getAccountNo(),account);
		return account;
	}
	@Override
	public boolean update(Account account) {
		if(AccountDBUtil.customerAccountDetails.containsKey(account.getAccountNo())) {
			AccountDBUtil.customerAccountDetails.put(account.getAccountNo(),account);
			return true;
		}
		return false;
	}
	@Override
	public List<Account> findAll() {
		return new ArrayList<Account>(AccountDBUtil.customerAccountDetails.values());
	}
	@Override
	public Account findOne(long accountNo) {
		return AccountDBUtil.customerAccountDetails.get(accountNo) ;
	}}
