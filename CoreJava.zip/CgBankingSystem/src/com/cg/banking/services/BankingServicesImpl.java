package com.cg.banking.services;

import java.util.List;

import com.cg.bankig.beans.Account;
import com.cg.bankig.beans.Transaction;
import com.cg.bankig.exceptions.AccountBlockedException;
import com.cg.bankig.exceptions.AccountNotFoundException;
import com.cg.bankig.exceptions.BankingServicesDownException;
import com.cg.bankig.exceptions.InsufficientAmountException;
import com.cg.bankig.exceptions.InvalidAccountTypeException;
import com.cg.bankig.exceptions.InvalidAmountException;
import com.cg.bankig.exceptions.InvalidPinNumberException;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;


public class BankingServicesImpl implements BankingServices {
	private AccountDAO customerData=new AccountDAOImpl();
	private TransactionDAO transacData = new TransactionDAOImpl();
	
	
	private final static float minBalance=1000;
	private final static int maxInvalidPinAttempts=3;

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(initBalance<=minBalance) throw new InvalidAmountException("Low Balance!!");
		Account AccountDetails=new Account(accountType,initBalance);
		AccountDetails=customerData.save(AccountDetails);
		transacData.save(AccountDetails.getAccountNo(), new Transaction(initBalance, "Deposit"));
		return AccountDetails;
	}
   @Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException,AccountBlockedException {
		Account customers=null;
		customers=getAccountDetails(accountNo);
		if(customers.getAccountStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("Account blocked!");
		else
			customers.setAccountBalance(customers.getAccountBalance()+amount);
		transacData.save(customers.getAccountNo(), new Transaction(amount, "Deposit"));
		return customers.getAccountBalance();
	}
  @Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) 
			throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, 
			AccountBlockedException {
		Account customers=null;
		customers=getAccountDetails(accountNo);
		if(customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException("Account Blocked");
		else if(customers.getPinNumber()!=pinNumber) {
			customers.incrPinAttempts();
			System.out.println("Invalid Pin,try again");
			
			if(customers.getPinAttempts()==maxInvalidPinAttempts) {
				customers.setAccountStatus("Blocked!!");
				throw new AccountBlockedException();
			}
			throw new InvalidPinNumberException();
			}
		else if(customers.getPinAttempts()>0 && !(customers.getAccountStatus().equalsIgnoreCase("Blocked!")))
			customers.resetPin();
		else if(customers.getAccountBalance()-amount<=minBalance)
			throw new InsufficientAmountException("BALANCE LOW");
		else
			customers.setAccountBalance(customers.getAccountBalance()-amount);
		transacData.save(customers.getAccountNo(), new Transaction(amount, "Withdraw"));
		return customers.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo=null;
		Account customerFrom=null;
		customerTo=getAccountDetails(accountNoTo);
		customerFrom=getAccountDetails(accountNoFrom);
		if(customerFrom.getAccountBalance()-transferAmount<=minBalance)
			throw new InsufficientAmountException("Low balance");
		if(customerFrom.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException("Invalid Pin, please try again");
		else {
			customerFrom.setAccountBalance(withdrawAmount(customerFrom.getAccountNo(),
					transferAmount,customerFrom.getPinNumber()));
			customerTo.setAccountBalance(depositAmount(customerTo.getAccountNo(),transferAmount));
		}
		return true;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account customers=null;
		customers=customerData.findOne(accountNo);
		if(customers==null)throw new AccountNotFoundException("Account not found");
		return customers;
	}
	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account> customers=customerData.findAll();
		return customers;
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return null;
	}
	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account customers=customerData.findOne(accountNo);
		if(customers==null)throw new AccountNotFoundException("Account not found");
		else if(customers.getAccountStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("Account blocked");
		return customers.getAccountStatus();
	}
}
