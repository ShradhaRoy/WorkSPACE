package com.cg.project.collections;

import java.util.LinkedList;
import java.util.Collections;
import java.util.LinkedList;


public class LinkedListClassDemo {
	public static void LinkedListClassDemo() {

	
		
			LinkedList<Associate>associates=new LinkedList<>();
			
			
			
			associates.add(new Associate(111,"Shradha","Roy",15075));
			associates.add(new Associate(112,"Sangita","Roy",21000));
			associates.add(new Associate(113,"Diya","Roy",15080));
			associates.add(new Associate(114,"Bibhas","Roy",150));
			associates.add(new Associate(115,"VijayLaxmi","Singh",1504));
			System.out.println(associates);
			
			//for(Associate str.arrList) {
				//System.out.println(str);
			
			//sorting
			
			Collections.sort(associates );
			
			for(Associate associate:associates) {
				System.out.println(associate);
			}
			
			System.out.println("================================");
			Collections.sort(associates, new AssociateComparator());
			
			for(Associate associate:associates) {
				System.out.println(associate);
			}
			
			
		
		
		
			
	}
	}

