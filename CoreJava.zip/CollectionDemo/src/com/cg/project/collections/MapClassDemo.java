package com.cg.project.collections;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

public class MapClassDemo {
	public static void hashTableClassWork() {
		Hashtable<Integer,Associate> associates=new Hashtable<>();

		associates.put(111, new Associate(111,"Satish","Mahajan",120000));
		associates.put(112,new Associate(112,"Sangita","Roy",120));
		associates.put(113,new Associate(113,"Bibhas","Roy",1200));
		associates.put(114,new Associate(114,"Diya","Roy",1000));
		
		Associate associate=associates.get(112);
		associates.remove(112);
		
		Set<Integer>keys=associates.keySet();
		
		for(Integer key:keys) {
			System.out.println(associates.get(key));
		}
		ArrayList<Associate>associateList=new ArrayList<>(associates.values());
		}
		
	}

