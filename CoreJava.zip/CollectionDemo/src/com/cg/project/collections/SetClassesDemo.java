package com.cg.project.collections;

import java.util.HashSet;


public class SetClassesDemo {
	public static void hashSetClassDemo() {
		HashSet<Associate>associates=new HashSet<>();
		associates.add(new Associate(111,"Shradha","Roy",15075));
		associates.add(new Associate(112,"Sangita","Roy",21000));
		associates.add(new Associate(113,"Diya","Roy",15080));
		associates.add(new Associate(114,"Bibhas","Roy",150));
		associates.add(new Associate(115,"VijayLaxmi","Singh",1504));
	}

}
