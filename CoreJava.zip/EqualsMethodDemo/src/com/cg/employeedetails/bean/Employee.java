package com.cg.employeedetails.bean;

public class Employee 
{     
	   private int EmployeeId;
	   private String firstName,lastName;
	   private float Salary;
	   
	   public Employee() {}
	   public Employee(int EmployeeId, float Salary, String firstName,String lastName) {
			super();
			this.EmployeeId = EmployeeId;
			this.Salary = Salary;
			this.firstName= firstName;
			this.lastName=lastName;
}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (EmployeeId != other.EmployeeId)
			return false;
		if (Float.floatToIntBits(Salary) != Float.floatToIntBits(other.Salary))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		return true;
	}
	public int getEmployeeId() {
		return EmployeeId;
	}
	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public float getSalary() {
		return Salary;
	}
	public void setSalary(float salary) {
		Salary = salary;
	}
}