package com.cg.employeedetails.main;

import com.cg.employeedetails.bean.Employee;

public class MainClass {
	public static void main(String[] args) {
		
	Employee emp1=new Employee(111, 9000, "Shradha","Roy");
	Employee emp2=new Employee(111, 9000, "Shradha","Roy");
	Object obj=emp2;
	if(emp1==emp2)
		System.out.println("it is same");
	else
		System.out.println("no, not same");
	if(emp1.equals(emp2))
	{
		System.out.println("same");
	}
	else
		System.out.println("not same");
	if(obj.equals(emp2))
	{
		System.out.println("again same");
	}
	

}
}
