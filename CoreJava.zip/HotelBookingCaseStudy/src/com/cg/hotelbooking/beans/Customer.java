package com.cg.hotelbooking.beans;

public class Customer {
	private String CustomerId;
	private String CustomerFirstname;
	private String CustomerLastName;
	private int

}
