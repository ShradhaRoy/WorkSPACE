package com.cg.project.client;

import java.io.File;
import java.io.IOException;

import com.cg.project.readwritework.ReadWriteWork;
import com.cg.project.readwritework.SerializationDemo;

public class MainClass {
	public static void main(String args[]) {
		try {
			/*File file=new File("d:\\DataFile.txt");
			if(!file.exists()) {
				file.createNewFile();
			}
			System.out.println(file.canWrite());
			System.out.println(file.canExecute());
			System.out.println(file.getName());
			System.out.println(file.getAbsolutePath());
			System.out.println(file.getPath());
			System.out.println(file.length());*/
		    
			//File fileFrom=new File("D:\\CiSession.txt");
			//File fileTo= new File("C:\\temp\\"+fileFrom.getName());
			
			
			File file=new File("D:\\CustomerData.txt");
			SerializationDemo.doSerialization(file);
			SerializationDemo.doDeSerialization(file);
			
			
			//ReadWriteWork.propertiesWork(fileFrom);
		}catch(IOException | ClassNotFoundException c) {
			c.printStackTrace();
		}
		
	
}}

