package com.cg.project.readwritework;

import java.io.Serializable;

public class Address implements Serializable {
	private String City;
	private String Country;
	public Address(String city, String country) {
		super();
		City = city;
		Country = country;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	
	

}
