package com.cg.mathproject.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mathproject.exception.NegativeNumberException;
import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathServicesImpl;

import junit.framework.Assert;

public class MathServicesTest {
	private static MathServices services;
	
	@BeforeClass
	public static void setUpTestEnv() {
		services=new MathServicesImpl();
	}
	@Test(expected=NegativeNumberException.class)
	public void testAddForFirstNumberInvalid()throws NegativeNumberException {
		services.add(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testAddForSecondNumberInvalid()throws NegativeNumberException {
		services.add(100, -200);
	}
	@Test
	public void testAddForBothValidNumber()throws NegativeNumberException {
		Assert.assertEquals(300, services.add(100, 200));
	}
	@Test(expected=NegativeNumberException.class)
	public void testSubForFirstNumberInvalid()throws NegativeNumberException {
		services.sub(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testSubForSecondNumberInvalid()throws NegativeNumberException {
		services.sub(100, -200);
	}
	@Test
	public void testSubForBothValidNumber()throws NegativeNumberException {
		Assert.assertEquals(300, services.sub(100, 200));
	}
	@Test(expected=NegativeNumberException.class)
	public void testDivForFirstNumberInvalid()throws NegativeNumberException {
		services.div(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testDivForSecondNumberInvalid()throws NegativeNumberException {
		services.div(100, -200);
	}
	@Test
	public void testDivForBothValidNumber()throws NegativeNumberException {
		Assert.assertEquals(300, services.div(100, 200));
	}
	@Test(expected=NegativeNumberException.class)
	public void testMultiForFirstNumberInvalid()throws NegativeNumberException {
		services.multi(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testMultiForSecondNumberInvalid()throws NegativeNumberException {
		services.multi(100, -200);
	}
	@Test
	public void testMultiForBothValidNumber()throws NegativeNumberException {
		Assert.assertEquals(300, services.multi(100, 200));
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}
}
