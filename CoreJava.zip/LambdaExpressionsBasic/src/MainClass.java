import com.cg.project.lambdainterface.FunctionalInterface1;
import com.cg.project.lambdainterface.FunctionalInterface2;

public class MainClass {

	public static void main(String[] args) {
		/*WorkService service=new WorkService() {
			@Override
			public void doSomeWork() {
				System.out.println("Work In Progress");
			}
		};
		
		service.doSomeWork();*/
		
		/*WorkServices service2=()->System.out.println("Work in Progress");
		callForWork(service2);
		callForWork(()->System.out.println("Finally work is done"));
	}*/
		
		/*FunctionalInterface1 ref1=(firstName,lastName)->System.out.println("Good afternoon "+firstName+" "+lastName);
		ref1.greetUser("Shradha","Roy");
	}*/
		FunctionalInterface2 ref2 = (a,b)->a+b;
	}

	public static void callForWork(WorkServices service) {
		service.doSomeWork();
			
			
		}

	}


