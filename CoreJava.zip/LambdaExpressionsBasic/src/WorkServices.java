
public interface WorkServices {
	public void doSomeWork();

}
