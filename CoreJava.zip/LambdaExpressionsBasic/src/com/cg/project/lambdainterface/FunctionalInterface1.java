package com.cg.project.lambdainterface;

public interface FunctionalInterface1 {
	void greetUser(String firstNmae, String lastName);

}
