package com.cg.mycasestudy.Client;

import com.cg.mycasestudy.services.EventManagementServices;
import com.cg.mycasestudy.services.EventManagementServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		
		EventManagementServices services=new EventManagementServicesImpl();
		int bookingId=services.acceptCustomerDetails("Shradha", "Roy", "9008907876", "shradha.roy305@gmail.com", "Pune", "22-11-1900", 100);
		System.out.println(bookingId);
		

	}

}
