package com.cg.mycasestudy.DBUtil;

import java.util.HashMap;

import com.cg.mycasestudy.beans.Customer;

public class EventDBUtil {
	public static HashMap<Integer,Customer> custData=new HashMap<>();
	public static int BOOKING_ID=1;
	public static int getBOOKING_ID(){
		return ++BOOKING_ID;
	}

}
