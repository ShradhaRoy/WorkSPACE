package com.cg.mycasestudy.beans;

public class BirthdayEvent {
	private String Venue;
	private String Date;
	private int bookingFare;
	
	
	public BirthdayEvent() {
		super();
		
	}


	public BirthdayEvent(String venue, String date, int bookingFare) {
		super();
		Venue = venue;
		Date = date;
		this.bookingFare = bookingFare;
	}


	public String getVenue() {
		return Venue;
	}


	public void setVenue(String venue) {
		Venue = venue;
	}


	public String getDate() {
		return Date;
	}


	public void setDate(String date) {
		Date = date;
	}


	public int getBookingFare() {
		return bookingFare;
	}


	public void setBookingFare(int bookingFare) {
		this.bookingFare = bookingFare;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Date == null) ? 0 : Date.hashCode());
		result = prime * result + ((Venue == null) ? 0 : Venue.hashCode());
		result = prime * result + bookingFare;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BirthdayEvent other = (BirthdayEvent) obj;
		if (Date == null) {
			if (other.Date != null)
				return false;
		} else if (!Date.equals(other.Date))
			return false;
		if (Venue == null) {
			if (other.Venue != null)
				return false;
		} else if (!Venue.equals(other.Venue))
			return false;
		if (bookingFare != other.bookingFare)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "BirthdayEvent [Venue=" + Venue + ", Date=" + Date + ", bookingFare=" + bookingFare + "]";
	}
	

}