package com.cg.mycasestudy.beans;

public class Customer {
	private String FirstName;
	private String LastName;
	private String ContactNo;
	private String emailId;
	private int bookingId;
	private BirthdayEvent event;
	public Customer() {
		super();
		
	}
	public Customer(String firstName, String lastName, String contactNo, String emailId, BirthdayEvent event) {
		super();
		FirstName = firstName;
		LastName = lastName;
		ContactNo = contactNo;
		this.emailId = emailId;
		this.event = event;
	}
	
	public Customer(String firstName, String lastName, String contactNo, String emailId, int bookingId,
			BirthdayEvent event) {
		super();
		FirstName = firstName;
		LastName = lastName;
		ContactNo = contactNo;
		this.emailId = emailId;
		this.bookingId = bookingId;
		this.event = event;
	}
	
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getContactNo() {
		return ContactNo;
	}
	public void setContactNo(String contactNo) {
		ContactNo = contactNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public BirthdayEvent getEvent() {
		return event;
	}
	public void setEvent(BirthdayEvent event) {
		this.event = event;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ContactNo == null) ? 0 : ContactNo.hashCode());
		result = prime * result + ((FirstName == null) ? 0 : FirstName.hashCode());
		result = prime * result + ((LastName == null) ? 0 : LastName.hashCode());
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((event == null) ? 0 : event.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (ContactNo == null) {
			if (other.ContactNo != null)
				return false;
		} else if (!ContactNo.equals(other.ContactNo))
			return false;
		if (FirstName == null) {
			if (other.FirstName != null)
				return false;
		} else if (!FirstName.equals(other.FirstName))
			return false;
		if (LastName == null) {
			if (other.LastName != null)
				return false;
		} else if (!LastName.equals(other.LastName))
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (event == null) {
			if (other.event != null)
				return false;
		} else if (!event.equals(other.event))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Customer [FirstName=" + FirstName + ", LastName=" + LastName + ", ContactNo=" + ContactNo + ", emailId="
				+ emailId + ", event=" + event + "]";
	}
	
	
	

}
