package com.cg.mycasestudy.daoservices;

import java.util.List;

import com.cg.mycasestudy.beans.Customer;

public interface CustomerDAO {
	Customer save(Customer customer);
	boolean update(Customer customer);
	Customer findOne(int bookingId);
	List<Customer>findAll();

}
