package com.cg.mycasestudy.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.mycasestudy.DBUtil.EventDBUtil;
import com.cg.mycasestudy.beans.Customer;


public class CustomerDAOServicesImpl implements CustomerDAO{

	@Override
	public Customer save(Customer customer) {
		customer.setBookingId(EventDBUtil.getBOOKING_ID());
		EventDBUtil.custData.put(customer.getBookingId(),customer);
		return customer;
	}

	@Override
	public boolean update(Customer customer) {
		
		return false;
	}

	@Override
	public Customer findOne(int bookingId) {
		return EventDBUtil.custData.get(bookingId);
	}

	@Override
	public List<Customer> findAll() {
		
		return new ArrayList<>(EventDBUtil.custData.values());
	}
	

}
