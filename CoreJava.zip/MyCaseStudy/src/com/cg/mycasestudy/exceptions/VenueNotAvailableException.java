package com.cg.mycasestudy.exceptions;

public class VenueNotAvailableException extends Exception {

}
