package com.cg.mycasestudy.services;

import java.util.List;

import com.cg.mycasestudy.beans.Customer;

public interface EventManagementServices {
	int acceptCustomerDetails(String firstName, String lastName, String contactNo, String emailId, String venue, String date, int bookingFare);
	
	List<Customer> getAllCustomerDetails();

}
