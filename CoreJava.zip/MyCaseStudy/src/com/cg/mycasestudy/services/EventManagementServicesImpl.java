package com.cg.mycasestudy.services;

import java.util.List;

import com.cg.mycasestudy.beans.BirthdayEvent;
import com.cg.mycasestudy.beans.Customer;
import com.cg.mycasestudy.daoservices.CustomerDAO;
import com.cg.mycasestudy.daoservices.CustomerDAOServicesImpl;

public class EventManagementServicesImpl implements EventManagementServices {
	private CustomerDAO customerDao=new CustomerDAOServicesImpl();

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String contactNo, String emailId, String venue,
			String date, int bookingFare) {
		Customer customer=new Customer(firstName, lastName, contactNo, emailId, new BirthdayEvent(venue, date, bookingFare));
		customer= customerDao.save(customer);
		return customer.getBookingId();
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		
		return customerDao.findAll();
	}
	
	

}
