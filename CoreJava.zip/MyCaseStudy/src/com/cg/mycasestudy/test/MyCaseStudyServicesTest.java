package com.cg.mycasestudy.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyCaseStudyServicesTest {
	public void meth()
	{
		method1.horse;
	}



}
