import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainClass {
	public static void main(String args[]) {
		method5();
	}
	public static void method1() {
		String str="Hello Welc348660me to Jav4a Full Stack Training";
		Pattern pattern=Pattern.compile("\\d*");
		Matcher matcher=pattern.matcher(str);
		while(matcher.find()) {
			System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
		}
		
	}
	public static void method2() {
		String str="Hello Welc348660me to Jav4a Full Stack Training";
		Pattern pattern=Pattern.compile("\\d+");
		Matcher matcher=pattern.matcher(str);
		while(matcher.find()) {
			System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());

}}
		public static void method3() {
			String str="Hello Welc348660me to Jav4a Full Stack Training";
			Pattern pattern=Pattern.compile("\\d?");
			Matcher matcher=pattern.matcher(str);
			while(matcher.find()) {
				System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
			}}
		
		
		
			public static void method5() {
				String str="Hello Welc348660me to Jav4a Full Stack Training";
				Pattern pattern=Pattern.compile("\\s");
				Matcher matcher=pattern.matcher(str);
				while(matcher.find()) {
					System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
}}}