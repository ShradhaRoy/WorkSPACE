package com.cg.project.client;

import com.cg.project.threadwork.RunnableResource.RunnableResource;

public class MainClass {

	public static void main(String[] args) throws InterruptedException {
		RunnableResource resource=new RunnableResource();
		
		Thread th1=new Thread(resource,"tickThread");
		Thread th2=new Thread(resource,"tockThread");
		th1.start();
		th1.join();
		th2.start();
		System.out.println("main thread ends here");

	}

}
