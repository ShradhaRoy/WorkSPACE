package com.cg.project.threadwork.RunnableResource;

public class RunnableResource implements Runnable {
	
	@Override
	public void run() {
		
		Thread t=Thread.currentThread();
		
		if(t.getName().equals("tickThread"))
				for(int i=1;i<=10;i++) 
					System.out.println("Tick  "+i+ " "+t.getName());
		try {
			for(int i=1;i<=10;i++) {
			Thread.sleep(1000);
			System.out.println("Tick "+i+" "+t.getName());
			}
		}catch (InterruptedException e) {
			e.printStackTrace();
		}
				
			if(t.getName().equals("tockThread"))
					for(int i=1;i<=10;i++) 
						System.out.println("Tock  "+i+" "+t.getName());
				
				try {
					for(int i=1;i<=10;i++) {
						Thread.sleep(1000);
						System.out.println("Tick "+i+" "+t.getName());
						}
					}catch (InterruptedException e) {
						e.printStackTrace();
					}
					
			System.out.println("End of THread Task");
		}
	}
	
