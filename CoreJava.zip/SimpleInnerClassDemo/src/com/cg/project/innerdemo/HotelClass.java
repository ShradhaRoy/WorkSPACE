package com.cg.project.innerdemo;

public class HotelClass {
	interface FoodOrderLisnter{
		void cookAfood(String foodName);
	}
		
	public class VegKitchen implements FoodOrderLisnter{

		@Override
		public void cookAfood(String foodName) {
				System.out.println(foodName+ "is ready");
			
		}
	}
	public class NonVegKitchen implements FoodOrderLisnter{

		@Override
		public void cookAfood(String foodName) {
				System.out.println(foodName+ "is ready");
			
		}
	}
	}

