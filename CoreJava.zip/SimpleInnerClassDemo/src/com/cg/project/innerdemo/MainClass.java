package com.cg.project.innerdemo;

import com.cg.project.innerdemo.HotelClass.NonVegKitchen;

public class MainClass {

	public static void main(String[] args) {
		//Simple inner class
		HotelClass hotel=new HotelClass();
		
		HotelClass.VegKitchen vegKitchen=hotel.new VegKitchen();
		
		HotelClass.NonVegKitchen nonvegKitchen=hotel.new NonVegKitchen();
		
		

	}

}
