package com.cg.project.innerdemo2;

public class HotelClass2 {
		interface FoodOrderLisnter{
			void cookAfood(String foodName);
		}
			
		static class VegKitchen implements FoodOrderLisnter{

			@Override
			public void cookAfood(String foodName) {
					System.out.println(foodName+ "is ready");
				
			}
		}
		static class NonVegKitchen implements FoodOrderLisnter{

			@Override
			public void cookAfood(String foodName) {
					System.out.println(foodName+ "is ready");
				
			}
		}
		}


