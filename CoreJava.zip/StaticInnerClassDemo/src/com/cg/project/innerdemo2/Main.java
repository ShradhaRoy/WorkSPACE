package com.cg.project.innerdemo2;

public class Main {
	public static void main(String[] args) {
		//Simple inner class
		HotelClass2 hotel=new HotelClass2();
		
		HotelClass2.VegKitchen vegKitchen=new HotelClass2.VegKitchen();
		
		HotelClass2.NonVegKitchen nonvegKitchen=new HotelClass2.NonVegKitchen();
		
		

	}

}
