package com.cg.studentenrollment.beans;

public class Department {
	private int DeptId;
	private String DeptName;
	private String DeptHOD;
	private String deptFloor;
	public Department() {
		super();
		
	}
	public Department(int deptId, String deptName, String deptHOD, String deptFloor) {
		super();
		DeptId = deptId;
		DeptName = deptName;
		DeptHOD = deptHOD;
		this.deptFloor = deptFloor;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((DeptHOD == null) ? 0 : DeptHOD.hashCode());
		result = prime * result + DeptId;
		result = prime * result + ((DeptName == null) ? 0 : DeptName.hashCode());
		result = prime * result + ((deptFloor == null) ? 0 : deptFloor.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Department other = (Department) obj;
		if (DeptHOD == null) {
			if (other.DeptHOD != null)
				return false;
		} else if (!DeptHOD.equals(other.DeptHOD))
			return false;
		if (DeptId != other.DeptId)
			return false;
		if (DeptName == null) {
			if (other.DeptName != null)
				return false;
		} else if (!DeptName.equals(other.DeptName))
			return false;
		if (deptFloor == null) {
			if (other.deptFloor != null)
				return false;
		} else if (!deptFloor.equals(other.deptFloor))
			return false;
		return true;
	}
	public int getDeptId() {
		return DeptId;
	}
	public void setDeptId(int deptId) {
		DeptId = deptId;
	}
	public String getDeptName() {
		return DeptName;
	}
	public void setDeptName(String deptName) {
		DeptName = deptName;
	}
	public String getDeptHOD() {
		return DeptHOD;
	}
	public void setDeptHOD(String deptHOD) {
		DeptHOD = deptHOD;
	}
	public String getDeptFloor() {
		return deptFloor;
	}
	public void setDeptFloor(String deptFloor) {
		this.deptFloor = deptFloor;
	}
	@Override
	public String toString() {
		return "Department [DeptId=" + DeptId + ", DeptName=" + DeptName + ", DeptHOD=" + DeptHOD + ", deptFloor="
				+ deptFloor + "]";
	}
	
	

}
