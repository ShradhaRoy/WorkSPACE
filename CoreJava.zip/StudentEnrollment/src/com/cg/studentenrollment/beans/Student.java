package com.cg.studentenrollment.beans;

public class Student {
	private long StudentId;
	private String StudentName;
	private String StudentGender;
	private String StudentCity;
	Department department;
	private String StudentContact;
	public Student() {
		super();
		
	}
	public Student(long studentId, String studentName, String studentGender, String studentCity, Department department,
			String studentContact) {
		super();
		StudentId = studentId;
		StudentName = studentName;
		StudentGender = studentGender;
		StudentCity = studentCity;
		this.department = department;
		StudentContact = studentContact;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (StudentCity == null) {
			if (other.StudentCity != null)
				return false;
		} else if (!StudentCity.equals(other.StudentCity))
			return false;
		if (StudentContact == null) {
			if (other.StudentContact != null)
				return false;
		} else if (!StudentContact.equals(other.StudentContact))
			return false;
		if (StudentGender == null) {
			if (other.StudentGender != null)
				return false;
		} else if (!StudentGender.equals(other.StudentGender))
			return false;
		if (StudentId != other.StudentId)
			return false;
		if (StudentName == null) {
			if (other.StudentName != null)
				return false;
		} else if (!StudentName.equals(other.StudentName))
			return false;
		return true;
	}
	public long getStudentId() {
		return StudentId;
	}
	public void setStudentId(long l) {
		StudentId = l;
	}
	public String getStudentName() {
		return StudentName;
	}
	public void setStudentName(String studentName) {
		StudentName = studentName;
	}
	public String getStudentGender() {
		return StudentGender;
	}
	public void setStudentGender(String studentGender) {
		StudentGender = studentGender;
	}
	public String getStudentCity() {
		return StudentCity;
	}
	public void setStudentCity(String studentCity) {
		StudentCity = studentCity;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public String getStudentContact() {
		return StudentContact;
	}
	public void setStudentContact(String studentContact) {
		StudentContact = studentContact;
	}
	@Override
	public String toString() {
		return "Student [StudentId=" + StudentId + ", StudentName=" + StudentName + ", StudentGender=" + StudentGender
				+ ", StudentCity=" + StudentCity + ", StudentContact=" + StudentContact + "]";
	}
	
	
	
	

}
