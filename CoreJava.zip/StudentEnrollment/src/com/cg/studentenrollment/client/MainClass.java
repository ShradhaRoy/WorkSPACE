package com.cg.studentenrollment.client;

public class MainClass {

	public static void main(String[] args) {
		

	}

}
