package com.cg.studentenrollment.daoservices;

import java.util.List;

import com.cg.studentenrollment.beans.Student;

public interface StudentDao {
	Student save(Student student);
	boolean update(Student student);
	Student findOne(String StudentId);
	List <Student> findAll();
	

}
