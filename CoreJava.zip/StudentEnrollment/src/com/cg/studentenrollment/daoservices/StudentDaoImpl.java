package com.cg.studentenrollment.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.studentenrollment.beans.Student;
import com.cg.studentenrollment.dbutil.StudentDBUtil;

public class StudentDaoImpl implements StudentDao {

	@Override
	public Student save(Student student) {
		student.setStudentId(StudentDBUtil.getSTUDENT_ID());
		StudentDBUtil.studentDetails.put((int) student.getStudentId(), student);
		return student;
	}

	@Override
	public boolean update(Student student) {
	
		return false;
	}

	@Override
	public Student findOne(String StudentId) {
		
		return StudentDBUtil.studentDetails.get(StudentId);
	}

	@Override
	public List<Student> findAll() {
		
		return new ArrayList<>(StudentDBUtil.studentDetails.values());
	}
	

}
