package com.cg.studentenrollment.dbutil;

import java.util.HashMap;

import com.cg.studentenrollment.beans.Student;

public class StudentDBUtil {
	public static HashMap<Integer,Student> studentDetails= new HashMap<>();
	public static long STUDENT_ID=101;
	public static long getSTUDENT_ID() {
		return ++STUDENT_ID;
		
	}
	

}
