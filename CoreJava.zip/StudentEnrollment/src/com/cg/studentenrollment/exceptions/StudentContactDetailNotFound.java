package com.cg.studentenrollment.exceptions;

public class StudentContactDetailNotFound extends Exception {

	public StudentContactDetailNotFound() {
		super();
		
	}

	public StudentContactDetailNotFound(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public StudentContactDetailNotFound(String message, Throwable cause) {
		super(message, cause);
		
	}

	public StudentContactDetailNotFound(String message) {
		super(message);
		
	}

	public StudentContactDetailNotFound(Throwable cause) {
		super(cause);
		
	}
	

}
