package com.cg.studentenrollment.exceptions;

public class StudentDetailNotFound extends Exception {

	public StudentDetailNotFound() {
		super();
		
	}

	public StudentDetailNotFound(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public StudentDetailNotFound(String message, Throwable cause) {
		super(message, cause);
		
	}

	public StudentDetailNotFound(String message) {
		super(message);
	
	}

	public StudentDetailNotFound(Throwable cause) {
		super(cause);
		
	}
	

}
