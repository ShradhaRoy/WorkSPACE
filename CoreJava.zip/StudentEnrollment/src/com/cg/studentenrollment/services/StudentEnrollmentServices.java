package com.cg.studentenrollment.services;

import java.util.List;

import com.cg.studentenrollment.beans.Department;
import com.cg.studentenrollment.beans.Student;
import com.cg.studentenrollment.exceptions.StudentContactDetailNotFound;
import com.cg.studentenrollment.exceptions.StudentDetailNotFound;

public interface StudentEnrollmentServices{
	Student getStudentContactNo(int StudentId)throws StudentContactDetailNotFound;
	int acceptStudentDetails(long studentId, String studentName, String studentGender, String studentCity, Department department,
			String studentContact)throws StudentDetailNotFound;
	List<Student>getStudentDetails();
	

}
