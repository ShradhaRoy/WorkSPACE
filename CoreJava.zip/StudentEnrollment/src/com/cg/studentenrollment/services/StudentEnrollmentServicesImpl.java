package com.cg.studentenrollment.services;

import java.util.List;

import com.cg.studentenrollment.beans.Department;
import com.cg.studentenrollment.beans.Student;
import com.cg.studentenrollment.daoservices.StudentDao;
import com.cg.studentenrollment.exceptions.StudentContactDetailNotFound;
import com.cg.studentenrollment.exceptions.StudentDetailNotFound;

public class StudentEnrollmentServicesImpl implements StudentEnrollmentServices {
	private StudentDao studentDao;
	public public StudentEnrollmentServicesImpl() {
		studentDao=new studentDaoImpl
	}

	@Override
	public Student getStudentContactNo(int StudentId) throws StudentContactDetailNotFound {
		
		return null;
	}

	@Override
	public int acceptStudentDetails(long studentId, String studentName, String studentGender, String studentCity,
			Department department, String studentContact) throws StudentDetailNotFound {
		
		return 0;
	}

	@Override
	public List<Student> getStudentDetails() {
		
		return null;
	}
	

}
