package com.cg.project.client;

import com.cg.project.threadwork.MyThread;

public class MainClass {
	public static void main(String[] args) {
		MyThread th1= new MyThread("tick thread");
		MyThread th2= new MyThread("tock thread");
		th1.start();
		th2.start();
	}

}
